string = str(input("Enter original string: "))
new_string = string.replace('or', '',1)
print(new_string)
