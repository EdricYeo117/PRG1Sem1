#input
number = int(input("Please enter a number: "))

#process

for i in range(1, 11):
    print(" ", number, "x", i, "=", i * number)

print("The End")
   
