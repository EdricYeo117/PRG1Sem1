n = int(input("Enter a number: "))

i = 1
while i <= 10:
    multi = n * i
    print(n, "x", i, "=", multi)
    i += 1

print("The End!")
