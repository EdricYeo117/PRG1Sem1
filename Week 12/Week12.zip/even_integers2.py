num_list = [10, -13, 50, 5, 7, 24, 65, -40, 44, 30]

def is_even(n):
    if n % 2 == 0:
        print(i)
        return True 
    else:
        return False
    
for i in num_list:
    is_even(i)